package com.example.academiaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcademiaSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
