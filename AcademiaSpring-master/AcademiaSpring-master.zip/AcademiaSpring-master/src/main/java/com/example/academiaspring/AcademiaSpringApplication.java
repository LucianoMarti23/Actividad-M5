package com.example.academiaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcademiaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcademiaSpringApplication.class, args);
	}

}
